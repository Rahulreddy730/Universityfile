﻿CREATE TABLE [dbo].[Subjects] (
    [SubId] INT          NOT NULL,
    [Name]  VARCHAR (50) NULL,
    PRIMARY KEY CLUSTERED ([SubId] ASC)
);

